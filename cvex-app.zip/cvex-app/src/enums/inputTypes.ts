enum inputTypes {
  "Text" = "text",
  "Password" = "Password",
}
export default inputTypes;
