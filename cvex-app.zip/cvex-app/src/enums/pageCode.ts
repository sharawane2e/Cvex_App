enum pageCode {
  "Login" = "1",
  "Introduction" = "2",
  "GI" = "3",
  "Diagnostic" = "4",
  "ThankYou" = "5",
  "Result"="6"
}
export default pageCode;
