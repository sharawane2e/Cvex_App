enum password {
  WelcomePassword = "CVEX+2022",
}
export default password;
